using LibraryMS.model;
using Microsoft.AspNetCore.Mvc;

namespace schoolMS.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

        private readonly ILogger<WeatherForecastController> _logger;
        private readonly studentdata _db;
        public WeatherForecastController(ILogger<WeatherForecastController> logger, studentdata db)
        {
            _logger = logger;
            _db = db;
        }

      
       

        [HttpPost("storeData")]
        public void GetData(student b1)
        {
            _db.Add(b1);
            _db.SaveChanges();
        }
        [HttpGet("GetData")]
        public IEnumerable<student> GetData()
        {
            return _db.db;
        }
    }
}