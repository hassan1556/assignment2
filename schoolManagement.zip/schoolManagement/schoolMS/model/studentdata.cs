﻿using Microsoft.EntityFrameworkCore;

namespace LibraryMS.model
{
    public class studentdata:DbContext
    {
        internal IEnumerable<student> db;

        public studentdata(DbContextOptions<studentdata> options) : base(options)
            {

            }
            public DbSet<student> students { get; set; }
        }
}
