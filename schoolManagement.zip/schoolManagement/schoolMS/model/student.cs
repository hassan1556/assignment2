﻿using System.ComponentModel.DataAnnotations;

namespace LibraryMS.model
{
    public class student
    {
        [Key]
        public int ID { get; set; }
        public String Name { get; set; }
        public string Department { get; set; }
    }
}
